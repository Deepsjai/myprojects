#ifndef OPTION
#define OPTION
#include <string> // not used
class option{
 private:
   double StikePrice, CPU,r,t,sigma;
   void init();             // private parameters and init function


public:
  option();  // default Constructor
 option(double , double , double, double, double );      //  Constructor that initialises the option class
 ~option();       // destructor
 
 double get_stikeprice(){return StikePrice;}
 double get_CPU(){return CPU;}
 double get_r(){return r;}
 double get_t(){return t;}
 double get_sigma(){return sigma;}
 void set_stikeprice(double a){StikePrice=a;} // not used set_
 void set_CPU(double b){CPU =b;}
 void set_r(double c){r=c;}
 void set_t(double d){t=d;}
 void set_sigma(double f){sigma =f;}
};


 
#endif