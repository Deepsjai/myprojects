#include <boost/random.hpp>
#include <boost/random/normal_distribution.hpp>

int main()
{
  boost::mt19937 rng; // Seed can be set if you want (it's not relevant)

  boost::normal_distribution<> nd(0.0, 1.0);

  boost::variate_generator<boost::mt19937&,
                           boost::normal_distribution<> > var_nor(rng, nd);

  for(int i = 0; i < 10; ++i)
  {
    double d = var_nor();
    std::cout << d << std::endl;
  }
}
