#ifndef PRICING_METHOD
#define PRICING_METHOD
#include <string> // not used

class pricing_method{
public:
  virtual double Black_Scholes_Option_Price() = 0;

  
      //std::cout << "I am black scholes" << std::endl;
 // 

   virtual double Binomial_Option_Price()=0;

   
    //std::cout << "I am Binomial" << std::endl;
   
// virtual functions dont need it.......for debugging
};




#endif