#ifndef OPTION_PRICE
#define OPTION_PRICE
#include <string> // used 
#include "option.h"
#include "pricing_method.h"
class Option_price: public pricing_method, public option{
public:
   std::string flag;
   Option_price(double sp, double cpu, double b, double time, double sig, std::string f);
   double n1;
   double sig;
   ~Option_price();
  double Black_Scholes_Option_Price();
  double Binomial_Option_Price(); 
  double getd();   
  double bisection(double Target,
                 double Low,
                 double High,
                 double Tolerance); 
                                              
//double Black_Scholes_Option_Price();

};








#endif