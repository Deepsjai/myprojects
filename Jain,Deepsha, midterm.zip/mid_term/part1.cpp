#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include <sstream>
#include <regex>
#include <ctime>
#include <numeric>
#include <boost/random.hpp>
#include <boost/random/normal_distribution.hpp>
#include "matplotlibcpp.h"
#include "option.h"
#include "pricing_method.h"
#include "Option_price.h"
namespace plt = matplotlibcpp;
using namespace std;

void option::init()									//init function
{
	StikePrice = 0.0;
	CPU = 0.0;
	r = 0.0;
    t =0.0;
    sigma = 0.0;
}

option::option()								//Default Constructor
{
   init();
}

option::option(double sp, double cpu, double b, double time, double sig)		//Another Constructor
{
	StikePrice = sp;
	CPU = cpu;
	r = b;
    t = time;
    sigma = sig;
}

option::~option()								//Destructor
{
}


Option_price::Option_price(double sp, double cpu, double b, double time, double sig, string f):option(sp, cpu, b, time,sig){
    flag = f;                       // constructor for the flag
}
Option_price::~Option_price()								//Destructor
{
}

double Option_price::Binomial_Option_Price()
{
  double r = get_r();
  double K = get_stikeprice();
  double sigma= get_sigma();
  double S = get_CPU();
  int n_p = 200;
  
  // no. of time periods
  double time = get_t(); //
  double r_inv = exp(-r*(time/n_p));
  double u = exp(sigma* sqrt(time/n_p));
  double d = 1/u;
  double p_up = (exp(r*(time/n_p))-d)/(u-d);
  double p_d = 1.0 - p_up;
  double u_u = u*u;

 std::vector<double> prices(n_p+1); 
  prices[0] = S*pow(d, n_p);// finding the lowest node element of the tree
  for (int i=1; i<=n_p; ++i) prices[i] = u_u*prices[i-1];
  std::vector<double> c_values(n_p+1); // value of corresponding call
  for (int i=0; i<=n_p; ++i) { 
      if(flag == "c"|| flag == "C")c_values[i] = fmax(0.0, (prices[i]-K));// flag for call option
      if(flag == "p"|| flag == "P")c_values[i] = fmax(0.0, (K-prices[i]));//flag for put
      }; //  payoffs at maturity 
for (int step=n_p-1; step>=0; --step) {
  for (int i=0; i<=step; ++i) {
  c_values[i] = (p_up*c_values[i+1]+ p_d*c_values[i])*r_inv;
}; 
};
return c_values[0]; 
}

double normalCDF(double x) 
{
    return erfc(-x / sqrt(2.0))/2.0;
}

double Option_price::getd(){
 return n1;
}


double Option_price::Black_Scholes_Option_Price(){
double K = get_stikeprice();
double S = get_CPU();
double r = get_r();
double time = get_t();
double sigma = get_sigma();
double timesqrt = sqrt(time);
double d1 = (log(S/K)+r*time)/(sigma*timesqrt)+0.5*sigma*timesqrt; 
double d2 = d1-(sigma*timesqrt);
n1 = normalCDF(d1);
double n2 = normalCDF(d2);
double c_price;
if (flag == "c"|| flag == "C"){
c_price = S*n1 - K*exp(-r*time)*n2; 
}
if (flag == "p"|| flag == "P"){
c_price = K*exp(-r*time)*(normalCDF(-d2)) - S*(normalCDF(-d1)); 
}
return c_price;
}

int main(){
boost::mt19937 rng;
boost::normal_distribution<> nd(0.0, 1.0);
boost::variate_generator<boost::mt19937&, 
                           boost::normal_distribution<> > var_nor(rng, nd);
    
    double T = 0.4;
    double Td = T;
    double u =0.05;
    double sigma = 0.24;
    double K = 105.0;
    double r = 0.025;
    double N =100.0;
    //int count =0;
    double deltat = T/N;
    vector < double> t_vec;
    vector < double> t_m_vect;
    double dt = 0;
    for(int i =0 ; i < N +1  ; i++){
        t_vec.push_back(dt);
        t_m_vect.push_back(Td);
        Td = Td - deltat;
        dt = dt + deltat;
        
    }
    t_m_vect.push_back(0.0);
    t_vec.push_back(0.404);
    vector <vector<double>> Sp;
    vector <vector<long double>> Cp; 
    vector <vector<double>> Delta; 
    vector <vector<double>> Bank_p; 
    vector <vector<double>> HE; 
    for (int i = 0; i < 1000; i++) { 
        std::vector<double> temp;
        std::vector<long double> tempc;
        std::vector< double> tempd;
        
         double S = 100;
         
         temp.push_back(S); 
         double a;
        for (double j = 0; j < N+1; j++) 
        {
            double d = var_nor();
            Option_price p1(K, S , r ,t_m_vect[j], sigma ,"c");
            long double C_black =p1.Black_Scholes_Option_Price();
            double del = p1.getd();
            tempd.push_back(del);
            tempc.push_back(C_black);
            S = S + (u*S*deltat)+(sigma*S*sqrt(deltat)*d);
            temp.push_back(S); 
            
        } 
       // t_vec.push_back(0.0);
       plt::plot(t_vec,temp);
       // t_vec.pop_back();
        Sp.push_back(temp); 
        Cp.push_back(tempc);
        Delta.push_back(tempd);
    }
      plt::show();
    plt::clf();
   // t_vec.pop_back();
for ( int i = 0; i < 1000; i++ )
 {
  std::vector< double> tempb;
  std::vector< double> temph;
  double B = 0;
   double H;
  for ( double j = 0; j < 100; j++ )
  {
    if(j == 0)
    {
        B = Cp[j][i] - (Delta[j][i]*Sp[j][i]);
        H = 0;
    }
    else
    {
     B = (Delta[j-1][i]*Sp[j][i]) + (tempb[j-1]*exp(r*deltat))- (Delta[j][i]*Sp[j][i]);
     H = (Delta[j-1][i]*Sp[j][i]) + (tempb[j-1]*exp(r*deltat)) - Cp[j][i];
     
    }
     tempb.push_back(B);
     
     temph.push_back(H);
     
  } 
   
   Bank_p.push_back(tempb); 
   temph.push_back(0.0);
    //t_vec.pop_back();
   //plt::plot(t_vec,temph);
   //t_vec.push_back(0.404);
   HE.push_back(temph);
  //std::cout << Bank_p[0][i]<< std::endl;
  //std::cout << HE[0][i]<< std::endl;
}
/*std::cout << " Stock Price"<<std::endl;
for ( int i =0; i < 1; i++)
 {
  for (int j = 0 ; j <100; j++ ) std::cout << Sp[j][i] << ' ';
   std::cout << std::endl;
 }

 std::cout << " Call Price"<<std::endl;
for ( int i =0; i < 1; i++)
 {
  for (int j = 0 ; j <100; j++ ) std::cout << Cp[j][i] << ' ';
   std::cout << std::endl;
 }
*/

std::cout << " Banking Position"<<std::endl;
 for ( int i =0; i < 1; i++)
 {
  for (int j = 0 ; j <100; j++ ) std::cout << Bank_p[j][i] << ' ';
   std::cout << std::endl;
 }
 std::cout << std::endl;
 std::cout << " Hedging Error"<<std::endl;
 for ( int i =0; i < 1; i++)
 {
  for (int j = 0 ; j <100; j++ ) std::cout << HE[i][j] << ' ';
   std::cout << std::endl;
 }
 //std::cout <<  t_vec.size()    << std::endl;
 //t_vec.pop_back();
 vector <double> end_he;
 vector <double> index;

 for ( int i =0; i < 100; i++)
 {
  for (int j = 0 ; j <100; j++ ) {
      end_he.push_back(HE[i][j]);
   index.push_back(j);
  }
   plt::plot(index,end_he);
 }

/*for(int i =0 ; i < 1000; i++){

    end_he.push_back(HE[99][i]);
    index.push_back(i);
}
  plt::plot(index,end_he);
  */
  //plt::scatter(index,end_he);

 /*for ( const auto &row : HE )
{
   for ( const auto &s : row ) std::cout << plt::plot(t_vec,s) << ' ';
   std::cout << std::endl;
}
std::cout << HE[0].size() <<std::endl;
std::cout << t_vec.size() <<std::endl;*/
    //plt::plot(t_vec,x); 
  plt::show();
   // for ( const auto &s : row ) std::cout << s << ' ';
    return 0;
   
}